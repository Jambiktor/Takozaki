-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2024 at 02:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `takozaki`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_on_table`
--

CREATE TABLE `add_on_table` (
  `add_on_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_on_table`
--

INSERT INTO `add_on_table` (`add_on_id`, `product_id`, `name`, `price`) VALUES
(6, 7, 'Bonito Flakes', 10),
(7, 7, 'Pork Floss', 10);

-- --------------------------------------------------------

--
-- Table structure for table `option_table`
--

CREATE TABLE `option_table` (
  `option_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `option_table`
--

INSERT INTO `option_table` (`option_id`, `product_id`, `name`, `price`) VALUES
(5, 7, 'Barkada', 49);

-- --------------------------------------------------------

--
-- Table structure for table `product_table`
--

CREATE TABLE `product_table` (
  `product_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `image_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_table`
--

INSERT INTO `product_table` (`product_id`, `name`, `price`, `image_file`) VALUES
(7, 'Takoyaki', 49, '669a21052e050.png');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `user_id` int(11) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `housenum` varchar(100) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `image_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`user_id`, `admin`, `username`, `password`, `number`, `first_name`, `last_name`, `housenum`, `barangay`, `image_file`) VALUES
(1, 0, 'Dave', '$2y$10$kTtVq0L226PWpmsCq7iaxelWt6wZKb4sk6TQTiM4xnoASpbmEyqpS', '09123456789', 'John Kenneth', 'Tan', '123 Village', 'Calibuyo', ''),
(2, 1, 'Kalbo', '$2y$10$utF8N49bhQQIsy74ZXkquedn9DGeir0fDhDU17kdshn6w2ngXCSK2', '09123456789', 'John Kenneth', 'Tan', '123 Village', 'asd', '');

-- --------------------------------------------------------

--
-- Table structure for table `variation_table`
--

CREATE TABLE `variation_table` (
  `variation_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `variation_table`
--

INSERT INTO `variation_table` (`variation_id`, `product_id`, `name`, `image_file`) VALUES
(6, 6, '3123', '6698a1ccc351c.png'),
(7, 7, 'Octobits', '6698c414c5b60.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_on_table`
--
ALTER TABLE `add_on_table`
  ADD PRIMARY KEY (`add_on_id`);

--
-- Indexes for table `option_table`
--
ALTER TABLE `option_table`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `variation_table`
--
ALTER TABLE `variation_table`
  ADD PRIMARY KEY (`variation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_on_table`
--
ALTER TABLE `add_on_table`
  MODIFY `add_on_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `option_table`
--
ALTER TABLE `option_table`
  MODIFY `option_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_table`
--
ALTER TABLE `product_table`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `variation_table`
--
ALTER TABLE `variation_table`
  MODIFY `variation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
